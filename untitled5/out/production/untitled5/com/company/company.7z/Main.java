package com.company;

public class Main {

    public static void main(String[] args) {
	    //zad1.main();
        //zad2.main();
        zad3.main();
    }
}
